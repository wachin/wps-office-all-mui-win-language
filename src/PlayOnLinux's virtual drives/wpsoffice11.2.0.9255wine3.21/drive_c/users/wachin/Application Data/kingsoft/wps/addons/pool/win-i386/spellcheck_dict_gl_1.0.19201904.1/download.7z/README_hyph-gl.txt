Guionizador de galego para OpenOffice.org 3
Creado por Frco. Javier Rial Rodríguez (fjrial@mancomun.org) co asesoramento
lingüístico de Antón Gómez Méixome (meixome@mancomun.org) para Mancomún,
Centro de Referencia e Servizos de Software Libre.

1. Dereitos de autor
2. Contido

1. Dereitos de autor

Liberado baixo os termos da licenza GNU GPL (version 3).

2. Contido

O paquete contén o seguinte:

	hyph_gl_ANY.dic,  ficheiro de regras de separación.
	README-gl_ANY.txt, este ficheiro.
	LICENSES-gl.txt tradución ao galego da licenza GPLv3
	LICENSES-en.txt english version license GPLv3
