Hunspell dictionary for Turkish
Version 1.2.0 (Apr 04, 2015)

This dictionary is released under Mozilla Public License Version 2.0.

Original extension by Harun Reşit Zafer can be found here: https://extensions.libreoffice.org/extensions/turkish-spellcheck-dictionary
Software used to generate this dictionary: https://github.com/hrzafer/hunspell-tr
