Belarusian Spell Check Dictionary


Language: Belarusian (be-BY)
License:  Creative Commons CC-BY-SA
Author:   Mikalai Udodau <mikalai.udodau@gmail.com>
Origin:   Словазбор аўтарскі; арфаграфія паводле ТСБМ-2005
Packager: Mikalai Udodau
