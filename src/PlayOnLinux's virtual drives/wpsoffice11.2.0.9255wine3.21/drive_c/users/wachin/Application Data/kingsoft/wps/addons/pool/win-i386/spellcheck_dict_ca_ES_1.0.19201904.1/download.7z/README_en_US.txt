Sergio Sacristán - s2o
I created this dictionary by conversion of open-source dictionary from Libre Office. 