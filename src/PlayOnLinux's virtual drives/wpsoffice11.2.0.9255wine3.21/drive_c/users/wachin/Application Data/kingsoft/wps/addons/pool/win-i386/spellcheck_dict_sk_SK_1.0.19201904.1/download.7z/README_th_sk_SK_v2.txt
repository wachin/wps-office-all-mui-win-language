OpenThesaurus-SK - Slovak thesaurus - version for OpenOffice.org
Copyright (c) 2004-2013 Tibor Bako, yorik (zavinac) szm.sk,
Zdenko Podobný, zdposter (zavinac) gmail.com
Snapshot, generated automatically 2013-03-17 06:00, Language: sk
Homepage: http://www.sk-spell.sk.cx/thesaurus

Requirements: ==========================================================

 OpenOffice.org 3.0 or newer

Installation: ==========================================================

 Install file as OpenOffice extensions: in OpenOffice.org go to:
 Tools -> Extension Manager -> Add...

Licence:================================================================

Permission is hereby granted, free of charge, to any person obtaining
a copy of this data (the "Data"), to deal in the Data without
restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of
the Data, and to permit persons to whom the Data is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Data.

THE DATA ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE DATA OR THE USE OR OTHER DEALINGS IN THE DATA.

************************************************************************


Otvorený Slovenský Synonymický Slovník (Thesaurus) pre OpenOffice.org
3.0 a vyšší
Copyright (c) 2004-2013 Tibor Bako, yorik (zavinac) szm.sk,
Zdenko Podobný, zdposter (zavinac) gmail.com
Súbor bol vygenerovaný automaticky 2013-03-17 06:00,
Jazyk: sk
Domovská stránka: http://www.sk-spell.sk.cx/thesaurus
=======================================================================

Inštalácia: ===========================================================

 Súbor nainštalujte ako akýkoveľ iný zásuvný modul pre OpenOffice.org
 3.0: choďte do Nástroje -> Správca rozšírení... -> Pridať...


Zdenko Podobný <zdposter (zavinac) gmail (bodka) com>
http://lingucomponent.openoffice.org/download_dictionary.html
