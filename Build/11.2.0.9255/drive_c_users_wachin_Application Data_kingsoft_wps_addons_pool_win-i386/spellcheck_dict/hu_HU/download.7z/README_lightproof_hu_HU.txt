Hungarian sentence checker for LibreOffice, version 1.6.4
see git://anongit.freedesktop.org/libreoffice/lightproof
2009-2018 (c) László Németh, license: MPL 1.1 / GPLv3+ / LGPLv3+
