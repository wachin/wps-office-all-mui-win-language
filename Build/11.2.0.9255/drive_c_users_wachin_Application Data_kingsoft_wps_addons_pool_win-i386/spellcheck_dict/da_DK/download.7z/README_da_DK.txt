Stavekontrolden - Danish dictionary files for Hunspell and thesaurus files for MyThes
Version 2.4 - 2018-04-15
da_DK.dic, da_DK.aff, th_da_DK.dat, th_da_DK.idx: © 2018 Foreningen for frit tilgængelige sprogværktøjer - http://www.stavekontrolden.dk
These files are published under the following open source licenses:

GNU GPL version 2.0 - https://www.gnu.org/licenses/gpl-2.0.html
GNU LGPL version 2.1 - https://www.gnu.org/licenses/lgpl-2.1.html
Mozilla MPL version 1.1 - https://www.mozilla.org/en-US/MPL/1.1/

This dictionary is based on data from Det Danske Sprog- og Litteraturselskab
(The Danish Society for Language and Literature), https://dsl.dk.
Thanks to Lyngby-Taarbæk Kommune, Gribskov Kommune and Region Midtjylland for financial support to the thesaurus project.
