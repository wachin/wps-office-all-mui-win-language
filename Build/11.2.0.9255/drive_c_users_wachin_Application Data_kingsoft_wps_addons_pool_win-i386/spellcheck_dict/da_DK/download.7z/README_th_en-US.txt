These files are published under the following open source licenses:

GNU GPL version 2.0
GNU LGPL version 2.1
Mozilla MPL version 1.1

Stavekontrolden - Danish thesaurus files for OpenOffice.org 3.0.
Den Danske Ordbog - Synonymer
DanNet - leksikalsk-semantisk ordnet fra Det Danske Sprog- og Litteraturselskab og Center for Sprogteknologi, Københavns Universitet
© 2007 Foreningen for frit tilgængelige sprogværktøjer

Tak til Lyngby-Taarbæk Kommune, Gribskov Kommune og Region Midtjylland for
finansiel støtte til projektet

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
