These files are published under the following open source licenses:

GNU GPL version 2.0
GNU LGPL version 2.1
Mozilla MPL version 1.1

Stavekontrolden - Danish thesaurus files for OpenOffice.org 3.0.
Den Danske Ordbog - Synonymer
DanNet - leksikalsk-semantisk ordnet fra Det Danske Sprog- og Litteraturselskab og Center for Sprogteknologi, Københavns Universitet
© 2007 Foreningen for frit tilgængelige sprogværktøjer

Tak til Lyngby-Taarbæk Kommune, Gribskov Kommune og Region Midtjylland for
finansiel støtte til projektet

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

ChangeLog:

14. nov 2009: 15800 lemmas in wordnet and dsl synonyms. 11668 additional lemmas added from th_da_DK_not_wordnet.dat (3212 duplicates). 24255 total lemmas
22. maj 2009: 2009.05.22 usage translated into Danish 11.581/2.547
25. jan 2009: 0.1.9 Added helpcontent 11.518/2.522
29. dec. 2008: 0.1.8 Added words 11.211/2.447
8. dec. 2008: 0.1.7 repaired description in manifest.xml
6. dec. 2008: 0.1.6 Added words 10.413/2.299
23. nov. 2008: 0.1.5 Added words 9.548/2.123
14. nov. 2008: 0.1.4 Added words 8.903/1.059
09. nov. 2008: 0.1.3 Added words 5.047/1.104
28. oct. 2008: 0.1.2 Cleaned up some German words. Corrected a few errors. Added words. 3.772/898
19. oct. 2008: 0.1.1 First release

Statistics:

Words:29866
Synonym Groups:121402
Synonyms:170778